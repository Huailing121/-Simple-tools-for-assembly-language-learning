这是我在大学时期结合王爽老师的《汇编语言》学习汇编的基本工具//These are basic tool for learning assembly language according to Wangshuang's 《Assembly Language》.

包含如下部分：//including:

DOS仿真器 dosbox//DOS emulator

编辑器edit

编译器masm

链接器link

希望这些东西可以帮助到你。//Hope these can help you.